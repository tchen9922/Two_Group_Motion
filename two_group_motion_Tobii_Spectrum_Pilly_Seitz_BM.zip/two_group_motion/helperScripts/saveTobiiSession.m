function saveTobiiSession(eyeDir, sessionId, gazeData, gazeEvents, eyeTrackerInfo, aborted, state)
%SAVETOBIISESSION Save continuous Tobii gaze data and event timing.

if ~exist(eyeDir, 'dir')
    mkdir(eyeDir);
end

gazeFile = fullfile(eyeDir, sprintf('%s_tobii_gaze.mat', sessionId));
eventFile = fullfile(eyeDir, sprintf('%s_tobii_events.mat', sessionId));

save(gazeFile, 'gazeData', 'eyeTrackerInfo', 'aborted', 'state', '-v7.3');
save(eventFile, 'gazeEvents', 'eyeTrackerInfo', 'aborted', 'state', '-v7.3');
end
