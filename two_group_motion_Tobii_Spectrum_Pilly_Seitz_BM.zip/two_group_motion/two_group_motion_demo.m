function result = two_group_motion_demo(varargin)
%TWO_GROUP_MOTION_DEMO Compatibility wrapper for run_two_group_motion_demo.
result = run_two_group_motion_demo(varargin{:});
end
