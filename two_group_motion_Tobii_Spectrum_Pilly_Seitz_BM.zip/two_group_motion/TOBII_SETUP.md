# Tobii Pro Spectrum setup for two_group_motion

This version replaces the active EyeLink backend with the Tobii Pro SDK and is configured for a Tobii Pro Spectrum on Psychtoolbox screen 2.

## 1. Verify the Tobii SDK is available

In MATLAB, run:

```matlab
which EyeTrackingOperations
which ScreenBasedCalibration
which tobiiresearch
```

If those commands return valid SDK paths, leave `tobii_sdk_path` blank in `config/demo_default.json`.

If they return empty, set the SDK directory in `config/demo_default.json`, for example:

```json
"tobii_sdk_path": "C:\\path\\to\\TobiiPro.SDK.Matlab.Windows_2.1.0.1"
```

or pass it at launch:

```matlab
run_two_group_motion_demo('TobiiSDKPath', 'C:\\path\\to\\TobiiPro.SDK.Matlab.Windows_2.1.0.1')
```

## 2. Run on the external monitor

Screen 2 is the default in this version:

```matlab
run_two_group_motion_demo
```

You can explicitly specify it:

```matlab
run_two_group_motion_demo('ScreenNumber', 2)
```

The code checks that the discovered Tobii tracker is a Pro Spectrum.

## 3. Calibration

Calibration runs every session. The calibration uses the N-Tetris five-point Tobii screen-based calibration flow. During calibration:

- SPACE starts calibration.
- ESC aborts.
- S saves the calibration result.
- R repeats calibration.

Calibration is saved under the session's `data/tobii` directory.

## 4. Continuous gaze recording

After calibration, the experiment starts the Tobii gaze stream and repeatedly drains samples during fixation, stimulus presentation, and response collection.

Each gaze sample contains:

- `SystemTimeStamp`
- `DeviceTimeStamp`
- `GazeX`
- `GazeY`
- `PupilDiaL`
- `PupilDiaR`
- `TrialIndex`
- `ConditionDirectionDeg`
- `CoherencePercent`
- `CommonRotationDeg`

Session files are saved as:

```text
data/tobii/<session>_tobii_gaze.mat
data/tobii/<session>_tobii_events.mat
```

The event file records fixation onset, stimulus onset, response onset, space responses, and initial left/right response adjustments with their EEG trigger codes.

## 5. Skip Tobii for a test run

```matlab
run_two_group_motion_demo('SkipEyeTracker', true)
```

The older option remains accepted as an alias:

```matlab
run_two_group_motion_demo('SkipEyeLink', true)
```

## 6. OBS remains independent

OBS is ON by default:

```matlab
run_two_group_motion_demo
```

Skip it with:

```matlab
run_two_group_motion_demo('SkipOBS', true)
```

You can combine options:

```matlab
run_two_group_motion_demo('ScreenNumber', 2, ...
    'SkipOBS', true)
```
