function calibrationData = calibrateTobii(window, windowRect, eyetracker, expParams)
%CALIBRATETOBII Run the old Tetris Tobii screen-based calibration flow.

HideCursor(window);
Screen('TextFont', window, 'Arial');
Screen('TextSize', window, 24);

white = [1 1 1];
bgColor = [0 0 0];
redColor = [1 0 0];

KbName('UnifyKeyNames');
escapeKey = KbName('ESCAPE');
spaceKey = KbName('SPACE');
sKey = KbName('S');
rKey = KbName('R');

dotSizePix = 30;
innerDotSize = dotSizePix * 0.5;

calibrationData = [];
calibrationSaved = false;
calibrateAgain = true;

try
    while calibrateAgain
        Screen('FillRect', window, bgColor);
        message = [
            'Welcome to Tobii Calibration!' newline newline ...
            'Experimenter Controls:' newline ...
            '- SPACE: Start calibration' newline ...
            '- ESC: Abort calibration' newline];
        DrawFormattedText(window, message, 'center', 'center', white);
        Screen('Flip', window);

        while true
            [~, ~, keyCode] = KbCheck;
            if keyCode(escapeKey)
                ShowCursor(window);
                disp('Calibration aborted by experimenter.');
                return;
            elseif keyCode(spaceKey)
                break;
            end
        end

        calibration = ScreenBasedCalibration(eyetracker);
        try
            calibration.enter_calibration_mode();
        catch calibrationError
            if strcmp(calibrationError.identifier, 'EnterCalibrationMode:error210')
                fprintf('Previous calibration not completed; restarting...\n');
                calibration.leave_calibration_mode();
                calibration.enter_calibration_mode();
            else
                rethrow(calibrationError);
            end
        end

        [screenWidth, screenHeight] = Screen('WindowSize', window);
        calibrationPoints = [0.1 0.1; 0.9 0.1; 0.5 0.5; 0.1 0.9; 0.9 0.9];

        for pointIndex = 1:size(calibrationPoints, 1)
            point = calibrationPoints(pointIndex, :);
            Screen('FillRect', window, bgColor);
            Screen('DrawDots', window, point .* [screenWidth screenHeight], ...
                dotSizePix, redColor, [], 2);
            Screen('DrawDots', window, point .* [screenWidth screenHeight], ...
                innerDotSize, white, [], 2);
            Screen('Flip', window);
            pause(1);

            collectionResult = calibration.collect_data(point);
            fprintf('Point [%.2f, %.2f] result: %d\n', point(1), point(2), ...
                collectionResult.value);
            if collectionResult.value ~= CalibrationStatus.Success
                collectionResult = calibration.collect_data(point);
                fprintf('  Retry result: %d\n', collectionResult.value);
            end
        end

        DrawFormattedText(window, 'Computing calibration...', 'center', 'center', white);
        Screen('Flip', window);
        calibrationResult = calibration.compute_and_apply();
        calibration.leave_calibration_mode();

        if calibrationResult.Status ~= CalibrationStatus.Success
            disp('Calibration failed to apply; retrying full calibration.');
            continue;
        end

        plotCalibrationResult(calibrationResult);
        [leftLoss, rightLoss, totalSamples] = computeCalibrationLoss(calibrationResult);

        statsMessage = sprintf([ ...
            'Calibration Stats:\n' ...
            'Total samples: %d\n' ...
            'Left loss: %.1f%%\n' ...
            'Right loss: %.1f%%\n\n' ...
            'Press S=Save, R=Re-calibrate, ESC=Abort\n'], ...
            totalSamples, leftLoss, rightLoss);
        DrawFormattedText(window, statsMessage, 'center', 'center', white);
        Screen('Flip', window);

        while true
            [~, ~, keyCode] = KbCheck;
            if keyCode(escapeKey)
                ShowCursor(window);
                disp('Calibration aborted without saving.');
                return;
            elseif keyCode(sKey)
                saveCalibrationResult(expParams, calibrationResult);
                calibrationSaved = true;
                calibrationData = calibrationResult;
                disp('Calibration saved.');
                break;
            elseif keyCode(rKey)
                disp('Re-calibration selected.');
                break;
            end
        end

        if calibrationSaved
            calibrateAgain = false;
        end
    end
catch calibrationError
    ShowCursor(window);
    rethrow(calibrationError);
end

ShowCursor(window);
if ~calibrationSaved
    disp('No calibration data saved.');
end
end

function plotCalibrationResult(calibrationResult)
    figure('Name', 'Tobii Calibration Plot', 'NumberTitle', 'off');
    hold on;
    set(gca, 'YDir', 'reverse');
    axis([-0.2 1.2 -0.2 1.2]);

    calibrationPoints = calibrationResult.CalibrationPoints;
    for pointIndex = 1:numel(calibrationPoints)
        position = calibrationPoints(pointIndex).PositionOnDisplayArea;
        plot(position(1), position(2), 'ok', 'LineWidth', 10);

        for eyeIndex = 1:numel(calibrationPoints(pointIndex).LeftEye)
            if calibrationPoints(pointIndex).LeftEye(eyeIndex).Validity == ...
                    CalibrationEyeValidity.ValidAndUsed
                leftPosition = calibrationPoints(pointIndex).LeftEye(eyeIndex).PositionOnDisplayArea;
                plot(leftPosition(1), leftPosition(2), '-xr', 'LineWidth', 3);
            end
            if calibrationPoints(pointIndex).RightEye(eyeIndex).Validity == ...
                    CalibrationEyeValidity.ValidAndUsed
                rightPosition = calibrationPoints(pointIndex).RightEye(eyeIndex).PositionOnDisplayArea;
                plot(rightPosition(1), rightPosition(2), 'xb', 'LineWidth', 3);
            end
        end
    end

    xlabel('Normalized X Position');
    ylabel('Normalized Y Position');
    title('Calibration targets and gaze samples');
    hold off;
end

function [leftLoss, rightLoss, totalSamples] = computeCalibrationLoss(calibrationResult)
totalSamples = 0;
leftValid = 0;
rightValid = 0;
calibrationPoints = calibrationResult.CalibrationPoints;

for pointIndex = 1:numel(calibrationPoints)
    for eyeIndex = 1:numel(calibrationPoints(pointIndex).LeftEye)
        totalSamples = totalSamples + 1;
        if calibrationPoints(pointIndex).LeftEye(eyeIndex).Validity == ...
                CalibrationEyeValidity.ValidAndUsed
            leftValid = leftValid + 1;
        end
        if calibrationPoints(pointIndex).RightEye(eyeIndex).Validity == ...
                CalibrationEyeValidity.ValidAndUsed
            rightValid = rightValid + 1;
        end
    end
end

if totalSamples == 0
    leftLoss = NaN;
    rightLoss = NaN;
    return;
end

leftLoss = 100 * (1 - leftValid / totalSamples);
rightLoss = 100 * (1 - rightValid / totalSamples);
end

function saveCalibrationResult(expParams, calibrationResult)
outDir = expParams.subjPaths.eyeDir;
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

if isfield(expParams, 'subjID') && ~isempty(expParams.subjID)
    safeId = regexprep(char(expParams.subjID), '[^A-Za-z0-9_-]', '_');
else
    safeId = 'session';
end
fileName = sprintf('%s_tobii_calibration_%s.mat', safeId, datestr(now, 'yyyymmdd_HHMMSS'));
calibration_result = calibrationResult; %#ok<NASGU>
save(fullfile(outDir, fileName), 'calibration_result');
end
