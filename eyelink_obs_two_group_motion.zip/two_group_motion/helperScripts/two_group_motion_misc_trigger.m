%misc. eeg trigger codes, not experimental
function trigger = two_group_motion_misc_trigger(trigger_name)

switch lower(char(trigger_name))

    case 'fixation'
        trigger = 201;

    case {'response_circle', 'response circle'}
        trigger = 202;

    case {'left_arrow_response', 'left arrow response'}
        trigger = 203;

    case {'right_arrow_response', 'right arrow response'}
        trigger = 204;

    case {'space_bar_response', 'space bar response'}
        trigger = 205;

    otherwise
        error('Unknown miscellaneous EEG trigger: %s', trigger_name);
end

end