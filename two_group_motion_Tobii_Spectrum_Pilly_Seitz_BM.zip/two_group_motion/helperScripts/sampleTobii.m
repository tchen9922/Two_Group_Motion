function gazeData = sampleTobii(eyeTrackerHandle)
    %SAMPLETObII Drain Tobii Pro gaze samples into the two-group gaze-data shape.

    gazeData = emptyTobiiSampleStruct();
    if nargin < 1 || isempty(eyeTrackerHandle)
        return;
    end

    rawData = eyeTrackerHandle.get_gaze_data();
    if isa(rawData, 'StreamError')
        error('two_group_motion_demo:TobiiStreamError', ...
            'Tobii stream error: %s', char(rawData.Message));
    end

    for sampleIndex = 1:numel(rawData)
        gazeData(end + 1) = normalizeTobiiSample(rawData(sampleIndex)); %#ok<AGROW>
    end
end

function gazeData = emptyTobiiSampleStruct()
    gazeData = struct( ...
        'SystemTimeStamp', {}, ...
        'DeviceTimeStamp', {}, ...
        'GazeX', {}, ...
        'GazeY', {}, ...
        'PupilDiaL', {}, ...
        'PupilDiaR', {});
end

function gazeSample = normalizeTobiiSample(rawSample)
    leftGaze = vectorOrNaNs(getNestedValue(rawSample, ...
        {'LeftEye', 'GazePoint', 'OnDisplayArea'}, [NaN NaN]), 2);

    gazeSample = struct( ...
        'SystemTimeStamp', getNestedValue(rawSample, {'SystemTimeStamp'}, GetSecs), ...
        'DeviceTimeStamp', getNestedValue(rawSample, {'DeviceTimeStamp'}, NaN), ...
        'GazeX', leftGaze(1), ...
        'GazeY', leftGaze(2), ...
        'PupilDiaL', getNestedValue(rawSample, {'LeftEye', 'Pupil', 'Diameter'}, NaN), ...
        'PupilDiaR', getNestedValue(rawSample, {'RightEye', 'Pupil', 'Diameter'}, NaN));
end

function value = getNestedValue(value, fieldPath, defaultValue)
    for fieldIndex = 1:numel(fieldPath)
        fieldName = fieldPath{fieldIndex};
        if isempty(value) || ~hasFieldOrProperty(value, fieldName)
            value = defaultValue;
            return;
        end
        value = value.(fieldName);
    end

    if isempty(value)
        value = defaultValue;
    end
end

function tf = hasFieldOrProperty(value, fieldName)
tf = (isstruct(value) && isfield(value, fieldName)) || ...
    (isobject(value) && isprop(value, fieldName));
end

function value = vectorOrNaNs(value, expectedLength)
if ~isnumeric(value) || numel(value) < expectedLength
    value = NaN(1, expectedLength);
    return;
end

value = double(value(:)');
value = value(1:expectedLength);
end
