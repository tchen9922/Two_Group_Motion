function gazeData = appendTobiiSamples(gazeData, newSamples, trialIndex, conditionDirection, coherencePercent, rotationDeg)
%APPENDTOBIISAMPLES Add Tobii samples plus trial metadata to the session array.

if isempty(newSamples)
    return;
end

for i = 1:numel(newSamples)
    sample = newSamples(i);
    sample.TrialIndex = trialIndex;
    sample.ConditionDirectionDeg = conditionDirection;
    sample.CoherencePercent = coherencePercent;
    sample.CommonRotationDeg = rotationDeg;
    gazeData(end + 1) = sample; %#ok<AGROW>
end
end
