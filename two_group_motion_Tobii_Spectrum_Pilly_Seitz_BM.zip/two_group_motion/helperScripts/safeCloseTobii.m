function safeCloseTobii(eyeTracker)
%SAFECLOSETObII Best-effort stop/cleanup for a Tobii Pro SDK tracker.
if nargin < 1 || isempty(eyeTracker)
    return;
end

% The Tobii MATLAB SDK used by N-Tetris starts streaming via get_gaze_data.
% Some SDK releases expose stop_gaze_data; use it when available.
try
    if ismethod(eyeTracker, 'stop_gaze_data')
        eyeTracker.stop_gaze_data();
    end
catch ME
    warning('two_group_motion_demo:TobiiStopFailed', ...
        'Could not stop Tobii gaze stream cleanly: %s', ME.message);
end
end
