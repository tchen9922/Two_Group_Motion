function [eyeTracker, eyeInfo] = initTobiiTracker(window, windowRect, expParams)
%INITTOBIITRACKER Connect to the Tobii Pro Spectrum through Tobii Pro SDK.
% Reuses the discovery logic from the working N-Tetris Tobii implementation.

if nargin < 3
    expParams = struct();
end

if isfield(expParams, 'tobiiSDKPath') && ~isempty(expParams.tobiiSDKPath)
    addTobiiSDKPath(expParams.tobiiSDKPath);
end

requireTobiiFunction('EyeTrackingOperations');
requireTobiiFunction('ScreenBasedCalibration');

fprintf('[Tobii] Beginning initialization...\n');
tobiiOps = EyeTrackingOperations();
trackers = tobiiOps.find_all_eyetrackers();

if isempty(trackers)
    error('two_group_motion_demo:NoTobiiTracker', ...
        'No Tobii eye trackers discovered. Check the Pro Spectrum connection and Tobii runtime.');
end

eyeTracker = selectSpectrumTracker(trackers);

if isempty(eyeTracker) || ~isprop(eyeTracker, 'SerialNumber')
    error('two_group_motion_demo:InvalidTobiiTracker', ...
        'The discovered Tobii tracker handle is invalid.');
end

printTobiiTrackerInfo(eyeTracker);

[screenWidth, screenHeight] = Screen('WindowSize', window);

model = getTobiiProperty(eyeTracker, 'Model', 'Unknown');
address = getTobiiProperty(eyeTracker, 'Address', 'Unknown');
serial = getTobiiProperty(eyeTracker, 'SerialNumber', 'Unknown');

if isfield(expParams, 'eyeTrackerModel') && ~isempty(expParams.eyeTrackerModel)
    if ~contains(lower(char(model)), 'spectrum')
        error('two_group_motion_demo:WrongTobiiTracker', ...
            'Expected %s, but discovered Tobii model "%s" (serial %s).', ...
            char(expParams.eyeTrackerModel), char(model), char(serial));
    end
end

eyeInfo = struct( ...
    'backend', 'tobii', ...
    'model', char(model), ...
    'address', char(address), ...
    'serialNumber', char(serial), ...
    'screenNumber', 2, ...
    'screenPixels', [screenWidth, screenHeight], ...
    'initializedAt', datetime('now')); %#ok<NASGU>

fprintf('[Tobii] Connected to %s.\n', char(model));
fprintf('[Tobii] Serial: %s\n', char(serial));
fprintf('[Tobii] Screen: %d (%d x %d)\n', 2, screenWidth, screenHeight);
end

function addTobiiSDKPath(tobiiSDKPath)
if ~exist(tobiiSDKPath, 'dir')
    error('two_group_motion_demo:TobiiSDKPathMissing', ...
        'Configured Tobii SDK path does not exist: %s', tobiiSDKPath);
end

pathParts = strsplit(path, pathsep);
isTobiiPath = contains(lower(pathParts), 'tobiipro.sdk.matlab') | ...
    contains(lower(pathParts), [filesep 'tobiisdk' filesep]);
path(strjoin(pathParts(~isTobiiPath), pathsep));
addpath(genpath(tobiiSDKPath));
rehash toolboxcache;

fprintf('[Tobii] Added SDK path: %s\n', tobiiSDKPath);
end

function requireTobiiFunction(functionName)
if isempty(which(functionName))
    error('two_group_motion_demo:MissingTobiiFunction', ...
        'Required Tobii SDK function is not on the MATLAB path: %s', functionName);
end
end

function eyeTracker = selectSpectrumTracker(trackers)
if numel(trackers) == 1
    eyeTracker = trackers(1);
    model = getTobiiProperty(eyeTracker, 'Model', '');
    if ~contains(lower(char(model)), 'spectrum')
        error('two_group_motion_demo:WrongTobiiTracker', ...
            'Only one Tobii tracker was found, but it is "%s", not a Tobii Pro Spectrum.', char(model));
    end
    return;
end

for i = 1:numel(trackers)
    model = getTobiiProperty(trackers(i), 'Model', '');
    if contains(lower(char(model)), 'spectrum')
        eyeTracker = trackers(i);
        return;
    end
end

models = cell(1, numel(trackers));
for i = 1:numel(trackers)
    models{i} = char(getTobiiProperty(trackers(i), 'Model', 'Unknown'));
end
error('two_group_motion_demo:WrongTobiiTracker', ...
    'No Tobii Pro Spectrum found. Discovered trackers: %s', strjoin(models, ', '));
end

function printTobiiTrackerInfo(eyeTracker)
fprintf('[Tobii] Connected eye tracker:\n');
for name = {'Address','Name','SerialNumber','Model','FirmwareVersion','RuntimeVersion'}
    value = getTobiiProperty(eyeTracker, name{1}, '');
    if ~isempty(value)
        fprintf('  %s: %s\n', name{1}, char(value));
    end
end
end

function value = getTobiiProperty(obj, propertyName, defaultValue)
value = defaultValue;
try
    if isprop(obj, propertyName)
        value = obj.(propertyName);
    end
catch
    value = defaultValue;
end
end
